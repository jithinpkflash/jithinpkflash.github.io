<?php

$id = $_GET['i'];
$type = $_GET['t'];
if ($type == "movie") {
$app = "dplay://dplay.dx.am/play/?t=$type&i=$id";
} else
{
$season = $_GET['s'];
$app = "dplay://dplay.dx.am/play/?t=$type&i=$id&s=$season";

}


$url = "https://www.omdbapi.com/?apikey=a08c5ffa&i=tt$id";
if (isset($id) && isset($type)) {

} else
{
  $err = "noid";
}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
<meta name="description" content="DreamPLAY play this <?php echo $type; ?> in android app | Open url to see more information">
<script type="text/javascript">
function test2(){
    var di = document.getElementById("di");
    di.innerHTML = "app have not installed";
}
function newOpen(){//184 064 323 438
setTimeout(function () { window.location = "/Download/"; }, 25);
window.location = "<?php echo $app; ?>";
}
</script>
<script>

      var baseurl = "<?php echo $url; ?>";
      function loadPersons(){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET",baseurl,true);
        xmlhttp.onreadystatechange = function() {
          if(xmlhttp.readyState ===4 && xmlhttp.status ===200){
            var persons = JSON.parse(xmlhttp.responseText);
            var tbltop = `<i>`;
            //main table content we fill from data from the rest call
            var main ="";
	title = persons.Title;
	year = persons.Year;
	runtime = persons.Runtime;
	poster = persons.Poster;
	story = persons.Plot;
	imdb = persons.imdbRating;
	love = persons.imdbVotes;


            document.getElementById("poster").src = poster;
            document.getElementById("title").innerHTML = title;
            document.getElementById("year").innerHTML = year+" <b>|</b> " +runtime;
            document.getElementById("story").innerHTML = story;
   document.getElementById("hed").innerHTML = title+" Stream now on DreamPLAY";

          }
        };
        xmlhttp.send();
      }
      window.onload = function(){
        loadPersons();
      }

</script>
  <meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title id="hed">DreamPLAY App Stream now</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">
</head>
<body>
<!-- partial:index.partial.html -->

<div class="container" align="center">
  <div class="poster">
<img class="logo" src="/images/dreamplay_logo.png" width=120">
<?php 
if( $err == "noid" )
{

 echo ' 	
    <div class="poster__info">
<font size="4">ERROR 404</font>
<font color="gray" size="2"><br>It seems like the url is alterd and cannot be opend
</font>
<font color="gray" size="2"><br><a href="/">Back to Home</a></font>
          </div>';
}
else
{
echo '<img class="pstr" id="poster" src="poster.jpg" width="160">
	
    <div class="poster__info">
      <h1 class="poster__title" id="title">Loading..</h1>
      <p class="poster__text" id="year"></p>
	<p class="story" id="story"></p>
  <a class="play" onclick="return newOpen()" href="">Play in App</a>

    </div>
<p class="info">Note : if you installed the app it opens, if not installed we will take you to the download page</p>

';
}
?>
  </div>
</div>
<!-- partial -->

</body>
</html>