<?php
$api_key = 'a08c5ffa';
$imdb_movie_id = 'tt4154796';
if(empty($api_key))
{
	echo 'Get API key from http://www.omdbapi.com/';
	die();
}
$Url = 'http://www.omdbapi.com/?i=tt4154796&plot=full&apikey=a08c5ffa';
$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $json = curl_exec($ch);
    curl_close($ch);
$data = json_decode($json, true);
//Remove the below comment to see all possible data
//print_r($data);
echo '
<img src="'.$data['Poster'].'"/>
<hr/>
Title: <strong>'.$data['Title'].'</strong><br/>
Year: '.$data['Year'].'<br/>
Genre: '.$data['Genre'].'<br/>
Actors : '.$data['Actors'].'<br/>
Plot: '.$data['Plot'].'<br/>
IMDB Rating: <strong>'.$data['imdbRating'].'</strong> / Votes ('.$data['imdbVotes'].')<br/>
';
?>